function addDisease() {
    // Prompt the user for a new disease name
    var newDisease = prompt("Please enter the name of the disease:");
    
   // Check if the user entered a value and ensure it's not already in the list
    if (newDisease && !isDiseaseExist(newDisease)) {
        var datalist = document.getElementById("disease");
        var option = document.createElement("option");
        option.value = newDisease;
        datalist.appendChild(option);
      
          alert("New disease '" + newDisease + "' added to the list!");
        } else if (!newDisease) {
          alert("No disease name entered.");
        } else {
          alert("The disease '" + newDisease + "' already exists in the list."); 
        }
}
function isDiseaseExist(disease) {
    var datalist = document.getElementById("disease");
    var options = datalist.getElementsByTagName("option");
    for (var i = 0; i < options.length; i++) {
        if (options[i].value.toLowerCase() === disease.toLowerCase()) {
            return true; // Disease already exists
        }
    }
    return false; // Disease does not exist
}
function addPest() {
     // Prompt the user for a new pest name
    var newPest = prompt("Please enter the name of the pest:");
    
    // Check if the user entered a value and ensure it's not already in the list
    if (newPest && !isPestExist(newPest)) {
        var datalist = document.getElementById("pest");
        var option = document.createElement("option");
        option.value = newPest;
        datalist.appendChild(option);
      
            alert("New pest '" + newPest + "' added to the list!");
    } else if (!newPest) {
        alert("No pest name entered.");
    } else {
         alert("The pest '" + newPest + "' already exists in the list."); 
    }
}
function isPestExist(pest) {
    var datalist = document.getElementById("pest");
    var options = datalist.getElementsByTagName("option");
    for (var i = 0; i < options.length; i++) {
        if (options[i].value.toLowerCase() === pest.toLowerCase()) {
            return true; // Pest already exists
        }
    }
    return false; // Pest does not exist
}
function addDeficiency() {
    // Prompt the user for a new deficiency name
    var newDeficiency = prompt("Please enter the name of the deficiency:");
    
    // Check if the user entered a value and ensure it's not already in the list
    if (newDeficiency && !isDeficiencyExist(newDeficiency)) {
        var datalist = document.getElementById("deficiency");
        var option = document.createElement("option");
        option.value = newDeficiency;
        datalist.appendChild(option);
      
            alert("New deficiency '" + newDeficiency + "' added to the list!");
    } else if (!newDeficiency) {
        alert("No deficiency name entered.");
    } else {
        alert("The deficiency '" + newDeficiency + "' already exists in the list."); 
    }
}
function isDeficiencyExist(deficiency) {
    var datalist = document.getElementById("deficiency");
    var options = datalist.getElementsByTagName("option");
    for (var i = 0; i < options.length; i++) {
        if (options[i].value.toLowerCase() === deficiency.toLowerCase()) {
            return true; // Deficiency already exists
        }
    }
    return false; // Deficiency does not exist
}
function addFertilizer() {
     // Prompt the user for a new fertilizer name
    var newFertilizer = prompt("Please enter the name of the fertilizer:");
        
     // Check if the user entered a value and ensure it's not already in the list
    if (newFertilizer && !isFertilizerExist(newFertilizer)) {
        var datalist = document.getElementById("fertilizer");
        var option = document.createElement("option");
        option.value = newFertilizer;
        datalist.appendChild(option);
          
        alert("New fertilizer '" + newFertilizer + "' added to the list!");
        } else if (!newFertilizer) {
            alert("No fertilizer name entered.");
        } else {
            alert("The fertilizer '" + newFertilizer + "' already exists in the list."); 
        }
}
function isFertilizerExist(fertilizer) {
    var datalist = document.getElementById("fertilizer");
    var options = datalist.getElementsByTagName("option");
    for (var i = 0; i < options.length; i++) {
        if (options[i].value.toLowerCase() === fertilizer.toLowerCase()) {
            return true; // Fertilizer already exists
        }
    }
    return false; // Fertilizer does not exist
}               
