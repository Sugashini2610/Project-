<!-- create.html -->

<!-- all pages -->
<li class="nav-item d-none d-lg-flex">
    <a class="nav-link" href="pages/forms/create.html">
        <span class="btn btn-primary">+ Create new</span>
     </a>
</li>

<!-- Dashboard -->

<li class="nav-item">
            <a class="nav-link" href="../../index-2.html">
              <i class="fa fa-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
           
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#form-elements" aria-expanded="false" aria-controls="form-elements">
              <i class="fab fa-wpforms menu-icon"></i>
              <span class="menu-title">Employee</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="form-elements">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"><a class="nav-link" href="pages/forms/create.html">Create Employee</a></li>                
                <li class="nav-item"><a class="nav-link" href="pages/forms/advanced_elements.html">View Employee</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#editors" aria-expanded="false" aria-controls="editors">
              <i class="fas fa-pen-square menu-icon"></i>
              <span class="menu-title">Visit</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="editors">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"><a class="nav-link" href="pages/forms/text_editor.html">Create Visit</a></li>
                <li class="nav-item"><a class="nav-link" href="pages/forms/code_editor.html">View Visit</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#e-commerce" aria-expanded="false" aria-controls="e-commerce">
              <i class="fas fa-cog menu-icon"></i>
              <!-- <i class="fas fa-cog text-primary"></i> -->
              <span class="menu-title">Settings</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="e-commerce">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="pages/samples/invoice.html"> 1. </a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/samples/pricing-table.html"> 2.</a></li>
                <li class="nav-item"> <a class="nav-link" href="pages/samples/orders.html"> 3.</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pages/documentation.html">
              <i class="far fa-file-alt menu-icon"></i>
              <span class="menu-title">Report</span>
            </a>
          </li>
          
            <!-- create.html -->  
            <button type="button" class="btn btn-primary mr-2" onclick="window.location.href='dropify_img.html'">Next</button>
    
            <!--dropify_img -->
            <button type="button" class="btn btn-primary mr-2" onclick="window.location.href='disease.html'">Next</button>

           <!-- disease.html -->
           <button type="button" class="btn btn-primary mr-2" onclick="window.location.href='pest.html'">Next</button>


             


              
              
              
